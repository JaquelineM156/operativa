from test import test

if __name__=='__main__':
    test ()